//
//  ThingCell.m
//  BaseProject
//
//  Created by ios－10 on 15/11/19.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ThingCell.h"

@implementation ThingCell

- (TRImageView *)strBuIV
{
    if (!_strBuIV) {
        _strBuIV = [[TRImageView alloc] init];
        [self.contentView addSubview:_strBuIV];
        
        [_strBuIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(20);
            make.left.mas_equalTo(10);
            make.right.mas_equalTo(-10);
            make.height.mas_equalTo(270);
        }];
        
    }
    return _strBuIV;
}
- (UILabel *)strTtLb
{
    if (!_strTtLb) {
        _strTtLb = [[UILabel alloc] init];
        
        [self.contentView addSubview:_strTtLb];
        [_strTtLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.strBuIV.mas_bottom).mas_equalTo(10);
            make.left.mas_equalTo(20);
        }];
        _strTtLb.font = [UIFont boldFlatFontOfSize:18];
    }
    return _strTtLb;
}
- (UILabel *)strTcLb
{
    if (!_strTcLb) {
        _strTcLb = [[UILabel alloc] init];
        [self.contentView addSubview:_strTcLb];
        
        [_strTcLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.strTtLb.mas_bottom).mas_equalTo(20);
            make.leftMargin.mas_equalTo(self.strTtLb);
            make.right.mas_equalTo(-20);
            make.bottom.mas_equalTo(-50);
        }];
        _strTcLb.font = [UIFont systemFontOfSize:17];
        _strTcLb.textColor = [UIColor grayColor];
        _strTcLb.numberOfLines = 0;
    }
    return _strTcLb;
}
- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
