//
//  ThingCell.h
//  BaseProject
//
//  Created by ios－10 on 15/11/19.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TRImageView.h"

@interface ThingCell : UITableViewCell

@property (nonatomic, strong) TRImageView *strBuIV;
@property (nonatomic, strong) UILabel *strTtLb;
@property (nonatomic, strong) UILabel *strTcLb;

@end
