//
//  ArticleCell.h
//  BaseProject
//
//  Created by ios－10 on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ArticleCell : UITableViewCell

@property (nonatomic, strong) UILabel *strContTitleLb;
@property (nonatomic, strong) UILabel *strContAuthorLb;
@property (nonatomic, strong) UILabel *strContentLb;
@property (nonatomic, strong) UILabel *strContAuthorIntroduceLb;
@property (nonatomic, strong) UILabel *sAuthLb;

- (NSString *)stringInstrContentLb:(NSArray *)stringArr;
@end
