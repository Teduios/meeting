//
//  ArticleCell.m
//  BaseProject
//
//  Created by ios－10 on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ArticleCell.h"

@implementation ArticleCell

- (UILabel *)strContTitleLb
{
    if (!_strContTitleLb) {
        _strContTitleLb = [[UILabel alloc] init];
        [self.contentView addSubview:_strContTitleLb];
        
        [_strContTitleLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(10);
            make.centerX.mas_equalTo(0);
        }];
        
        _strContTitleLb.textAlignment = NSTextAlignmentCenter;
        _strContTitleLb.font = [UIFont boldFlatFontOfSize:14];
    }
    return _strContTitleLb;
}
- (UILabel *)strContAuthorLb
{
    if (!_strContAuthorLb) {
        _strContAuthorLb = [[UILabel alloc] init];
        [self.contentView addSubview:_strContAuthorLb];
        
        [_strContAuthorLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottomMargin.mas_equalTo(self.strContTitleLb.mas_bottom);
            make.left.mas_equalTo(self.strContTitleLb.mas_right).mas_equalTo(5);
            make.right.mas_equalTo(-10);
        }];
        
        _strContAuthorLb.font = [UIFont systemFontOfSize:12];
        _strContAuthorLb.textColor = [UIColor lightGrayColor];
    }
    return _strContAuthorLb;
}
- (UILabel *)strContentLb
{
    if (!_strContentLb) {
        _strContentLb = [[UILabel alloc] init];
        [self.contentView addSubview:_strContentLb];
        
        [_strContentLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.strContTitleLb.mas_bottom).mas_equalTo(5);
            make.left.mas_equalTo(10);
            make.right.mas_equalTo(-10);

        }];
        
        _strContentLb.font = [UIFont systemFontOfSize:13];
        _strContentLb.numberOfLines = 0;
    }
    return _strContentLb;
}
- (NSString *)stringInstrContentLb:(NSArray *)stringArr
{
    NSMutableString *mutableStr = [NSMutableString new];
    NSString *str = nil;
    for (NSString *value in stringArr) {
        if (value.length == 0) {
            continue;
        }
        str = [NSString stringWithFormat:@"%@\n", value];
        [mutableStr appendString:str];
    }
    return [mutableStr copy];
}
- (UILabel *)strContAuthorIntroduceLb
{
    if (!_strContAuthorIntroduceLb) {
        _strContAuthorIntroduceLb = [[UILabel alloc] init];
        [self.contentView addSubview:_strContAuthorIntroduceLb];
        [_strContAuthorIntroduceLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.strContentLb.mas_bottom).mas_equalTo(5);
            make.left.mas_equalTo(10);
            make.right.mas_equalTo(-10);
        }];
        
        _strContAuthorIntroduceLb.font = [UIFont systemFontOfSize:13];
        _strContAuthorIntroduceLb.numberOfLines = 0;
        _strContAuthorIntroduceLb.textColor = [UIColor lightGrayColor];
        
    }
    return _strContAuthorIntroduceLb;
}
- (UILabel *)sAuthLb
{
    if (!_sAuthLb) {
        _sAuthLb = [[UILabel alloc] init];
        [self.contentView addSubview:_sAuthLb];
        
        [_sAuthLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.strContAuthorIntroduceLb.mas_bottom).mas_equalTo(5);
            make.left.mas_equalTo(20);
            make.right.mas_equalTo(-20);
            make.bottom.mas_equalTo(-20);
        }];
        _sAuthLb.numberOfLines = 0;
        _sAuthLb.font = [UIFont systemFontOfSize:12];
        _sAuthLb.textColor = [UIColor grayColor];
    }
    return _sAuthLb;
}
- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
