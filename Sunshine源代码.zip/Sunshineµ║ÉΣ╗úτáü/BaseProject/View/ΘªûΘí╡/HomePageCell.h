//
//  HomePageCell.h
//  BaseProject
//
//  Created by ios－z on 15/11/15.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TRImageView.h"
@interface HomePageCell : UITableViewCell

@property (nonatomic,strong)UILabel *strMarketTimeLb;
@property (nonatomic,strong)UILabel *strContentLb;


@property (nonatomic,strong)UILabel *strHpTitleLb;

@property (nonatomic,strong)TRImageView *strOriginalImg;

@property (nonatomic,strong)UILabel *strAuthorLb;


@end
