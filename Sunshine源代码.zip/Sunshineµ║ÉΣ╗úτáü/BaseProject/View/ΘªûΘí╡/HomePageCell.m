//
//  HomePageCell.m
//  BaseProject
//
//  Created by ios－z on 15/11/15.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "HomePageCell.h"

@implementation HomePageCell
- (UILabel *)strHpTitleLb
{
    if (!_strHpTitleLb) {
        _strHpTitleLb = [[UILabel alloc] init];
        [self.contentView addSubview:_strHpTitleLb];
        _strHpTitleLb.font = [UIFont systemFontOfSize:15];
        _strHpTitleLb.textColor = kRGBColor(111, 112, 114);
        [_strHpTitleLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(15);
            make.left.mas_equalTo(10);
        }];
    }
    return _strHpTitleLb;
}


-(TRImageView *)strOriginalImg{
    if (!_strOriginalImg) {
        _strOriginalImg = [[TRImageView alloc]init];
        [self.contentView addSubview:_strOriginalImg];
        [_strOriginalImg mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.strHpTitleLb.mas_bottom).mas_equalTo(10);
            make.left.mas_equalTo(10);
            make.right.mas_equalTo(-10);
            make.height.mas_equalTo(270);
        }];
    }
    return _strOriginalImg;
}

- (UILabel *)strAuthorLb{
    if (!_strAuthorLb) {
        _strAuthorLb = [[UILabel alloc]init];
        [self.contentView addSubview:_strAuthorLb];
        _strAuthorLb.numberOfLines = 2;
        _strAuthorLb.font = [UIFont systemFontOfSize:14];
        _strAuthorLb.textAlignment = 2;
        _strAuthorLb.textColor = kRGBColor(111, 112, 114);
        [_strAuthorLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.strOriginalImg.mas_bottom).mas_equalTo(10);
            make.right.mas_equalTo(-10);
        }];
    }
    return _strAuthorLb;
}

-(UILabel *)strMarketTimeLb{
    if (!_strMarketTimeLb) {
        _strMarketTimeLb = [[UILabel alloc]init];
        [self.contentView addSubview:_strMarketTimeLb];
        _strMarketTimeLb.textColor = kMainColor;
        _strMarketTimeLb.font = [UIFont systemFontOfSize:20];
        [_strMarketTimeLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.strAuthorLb.mas_bottom).mas_equalTo(20);
            make.left.mas_equalTo(20);
            make.width.mas_greaterThanOrEqualTo(100);
        }];
    }
    return _strMarketTimeLb;
}
-(UILabel *)strContentLb{
    if (!_strContentLb) {
        _strContentLb = [[UILabel alloc]init];
        [self.contentView addSubview:_strContentLb];
        _strContentLb.numberOfLines = 0;
        self.strContentLb.textColor = kRGBColor(61, 62, 64);
        [_strContentLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.strMarketTimeLb.mas_right).mas_equalTo(10);
            make.top.mas_equalTo(self.strAuthorLb.mas_bottom).mas_equalTo(10);
            make.right.mas_equalTo(-20);
            make.bottom.mas_equalTo(-50);
        }];
    }
    
 
    return _strContentLb;
}


- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
