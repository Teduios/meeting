//
//  QuestionCell.h
//  BaseProject
//
//  Created by ios－10 on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TRImageView.h"
@interface QuestionCell : UITableViewCell

@property (nonatomic, strong) TRImageView *questionIV;
@property (nonatomic, strong) UILabel *strQuestionTitleLb;
@property (nonatomic, strong) UILabel *strQuestionContentLb;

@property (nonatomic, strong) TRImageView *answerIV;
@property (nonatomic, strong) UILabel *strAnswerTitleLb;
@property (nonatomic, strong) UILabel *strAnswerContentLb;
@property (nonatomic, strong) UILabel *sEditorLb;

- (NSString *)stringInstrContentLb:(NSArray *)stringArr;
@end
