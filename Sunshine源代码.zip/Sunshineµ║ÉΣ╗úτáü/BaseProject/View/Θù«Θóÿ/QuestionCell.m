//
//  QuestionCell.m
//  BaseProject
//
//  Created by ios－10 on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "QuestionCell.h"

@implementation QuestionCell

- (UILabel *)strQuestionTitleLb
{
    if (!_strQuestionTitleLb) {
        _strQuestionTitleLb = [[UILabel alloc] init];
        [self.contentView addSubview:_strQuestionTitleLb];
        [_strQuestionTitleLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(30);
            make.left.mas_equalTo(10);
            make.width.mas_lessThanOrEqualTo(200);
        }];
        _strQuestionTitleLb.numberOfLines = 0;
        _strQuestionTitleLb.font = [UIFont boldFlatFontOfSize:16];
    }
    return _strQuestionTitleLb;
}
- (TRImageView *)questionIV
{
    if (!_questionIV) {
        _questionIV = [[TRImageView alloc] init];
        [self.contentView addSubview:_questionIV];
        
        [_questionIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(10);
            make.right.mas_equalTo(-20);
            make.size.mas_equalTo(CGSizeMake(80, 80));
        }];
        
    }
    return _questionIV;
}


- (UILabel *)strQuestionContentLb
{
    if (!_strQuestionContentLb) {
        _strQuestionContentLb = [[UILabel alloc] init];
        [self.contentView addSubview:_strQuestionContentLb];
        
        [_strQuestionContentLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.questionIV.mas_bottom).mas_equalTo(10);
            make.left.mas_equalTo(10);
            make.right.mas_equalTo(-10);
        }];
        
        _strQuestionContentLb.numberOfLines = 0;
        _strQuestionContentLb.font = [UIFont systemFontOfSize:15];
    }
    return _strQuestionContentLb;
}

- (TRImageView *)answerIV
{
    if (!_answerIV) {
        _answerIV = [[TRImageView alloc] init];
        [self.contentView addSubview:_answerIV];
        
        [_answerIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.strQuestionContentLb.mas_bottom).mas_equalTo(5);
            make.right.mas_equalTo(-20);
            make.size.mas_equalTo(CGSizeMake(80, 80));
        }];
    }
    return _answerIV;
}
- (UILabel *)strAnswerTitleLb
{
    if (!_strAnswerTitleLb) {
        _strAnswerTitleLb = [[UILabel alloc] init];
        
        [self.contentView addSubview:_strAnswerTitleLb];
        [_strAnswerTitleLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.strQuestionContentLb.mas_bottom).mas_equalTo(30);
            make.left.mas_equalTo(10);
            make.width.mas_lessThanOrEqualTo(200);
        }];
        _strAnswerTitleLb.numberOfLines = 0;
        _strAnswerTitleLb.font = [UIFont boldFlatFontOfSize:16];
    }
    return _strAnswerTitleLb;
}
- (UILabel *)strAnswerContentLb
{
    if (!_strAnswerContentLb) {
        _strAnswerContentLb = [[UILabel alloc] init];
        [self.contentView addSubview:_strAnswerContentLb];
        
        [_strAnswerContentLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.answerIV.mas_bottom).mas_equalTo(10);
            make.left.mas_equalTo(10);
            make.right.mas_equalTo(-10);
            
        }];
        _strAnswerContentLb.numberOfLines = 0;
        _strAnswerContentLb.font = [UIFont systemFontOfSize:15];
    }
    return _strAnswerContentLb;
}
- (UILabel *)sEditorLb
{
    if (!_sEditorLb) {
        _sEditorLb = [[UILabel alloc] init];
        [self.contentView addSubview:_sEditorLb];
        [_sEditorLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.strAnswerContentLb.mas_bottom).mas_equalTo(10);
            make.left.mas_equalTo(10);
            make.bottom.mas_equalTo(-50);
        }];
        _sEditorLb.font = [UIFont systemFontOfSize:14];
        _sEditorLb.textColor = [UIColor lightGrayColor];
    }
    return _sEditorLb;
}

- (NSString *)stringInstrContentLb:(NSArray *)stringArr
{
    NSMutableString *mutableStr = [NSMutableString new];
    NSString *str = nil;
    for (NSString *value in stringArr) {
        str = [NSString stringWithFormat:@"%@\n", value];
        [mutableStr appendString:str];
    }
    return [mutableStr copy];
}
- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
