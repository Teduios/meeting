//
//  HomeViewController.m
//  BaseProject
//
//  Created by ios－10 on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ATViewController.h"
#import "ArticleViewController.h"
#import "Factory.h"

@interface ATViewController ()

@end

@implementation ATViewController

+ (UINavigationController *)standardATNavi
{
    static UINavigationController *navi = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        ATViewController *vc = [[ATViewController alloc] initWithViewControllerClasses:[self viewControllerClasses] andTheirTitles:[self itemNames]];
        //例如设置第一个控制器的某个属性的值, KVC
        //vc setValue:[values[0]] forKey:keys[0]
        vc.menuViewStyle = WMMenuViewStyleDefault;
        vc.menuHeight = PAGETABBARH;
        vc.menuItemWidth = kWindowW;
        
        vc.keys = [self vcKeys];
        vc.values = [self vcValues];
        navi = [[UINavigationController alloc] initWithRootViewController:vc];
    });
    return navi;
}
//
+ (NSArray *)vcValues{
    NSMutableArray *arr = [NSMutableArray new];
    for (int i = 1; i < 11; i ++) {
        [arr addObject:@(i)];
    }
    return [arr copy];
}
/** 提供每个VC对应的key值数组 */
+ (NSArray *)vcKeys{
    NSMutableArray *arr = [NSMutableArray new];
    for (id obj in [self itemNames]) {
        [arr addObject:@"strRow"];
    }
    return [arr copy];
}

/** 提供题目数组 */
+ (NSArray *)itemNames{
    return @[@"PAGE 1", @"PAGE 2", @"PAGE 3", @"PAGE 4", @"PAGE 5", @"PAGE 6", @"PAGE 7", @"PAGE 8", @"PAGE 9", @"PAGE 10"];
}
/** 提供每个题目对应的控制器的类型。题目和类型数量必须一致 */
+ (NSArray *)viewControllerClasses{
    NSMutableArray *arr = [NSMutableArray new];
    for (id obj in [self itemNames]) {
        [arr addObject:[ArticleViewController class]];
    }
    return [arr copy];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    
    [Factory addMenuItemToVC:self];
    
    self.navigationItem.title = @"Sunshine";

    self.titleColorNormal = [UIColor grayColor];
    self.titleColorSelected = kMainColor;
    self.titleSizeNormal = 10;
    self.titleSizeSelected = 20;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
