//
//  ArticleViewController.m
//  BaseProject
//
//  Created by ios－z on 15/11/14.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ArticleViewController.h"
#import "ArticleViewModel.h"
#import "ArticleCell.h"
#import "MobClick.h"

@interface ArticleViewController () <UITableViewDataSource, UITableViewDelegate, AVSpeechSynthesizerDelegate>
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) ArticleViewModel *articleVM;

//朗读按钮
@property (nonatomic, strong) UIButton *readBtn;
@property (nonatomic, strong) NSString *readContent;
@property(nonatomic,strong) AVSpeechSynthesizer *syn;
@end

@implementation ArticleViewController

- (AVSpeechSynthesizer *)syn {
    if(_syn == nil) {
        _syn = [[AVSpeechSynthesizer alloc] init];
        _syn.delegate = self;
    }
    return _syn;
}
- (UIButton *)readBtn
{
    if (!_readBtn) {
        _readBtn = [UIButton buttonWithType:UIButtonTypeSystem];
        [_readBtn setBackgroundImage:[UIImage imageNamed:@"toolbar_play_h_p"] forState:UIControlStateNormal];
        [_readBtn setBackgroundImage:[UIImage imageNamed:@"toolbar_pause_h_p"] forState:UIControlStateSelected];
        [self.tableView addSubview:_readBtn];
        
        [_readBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(0);
            make.left.mas_equalTo(0);
            make.size.mas_equalTo(CGSizeMake(30, 30));
        }];
        
        [_readBtn bk_addEventHandler:^(id sender) {
            if (kAppDelegate.isOnLine) {
                if (self.syn.speaking) {
                    [self.syn stopSpeakingAtBoundary:AVSpeechBoundaryImmediate];
                }else{
                    dispatch_async(dispatch_get_global_queue(0, 0), ^{
                        AVSpeechUtterance *utt = [AVSpeechUtterance speechUtteranceWithString:_readContent];
                        utt.voice = [AVSpeechSynthesisVoice voiceWithLanguage:@"zh-CN"];
                        [self.syn speakUtterance:utt];
                    });
                }
            }else{
                [self showErrorMsg:@"朗读需要联网"];
            }
            
        } forControlEvents:UIControlEventTouchUpInside];
    }
    return _readBtn;
}

- (UITableView *)tableView
{
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
        
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.allowsSelection = NO;
        _tableView.showsVerticalScrollIndicator = NO;
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        
        [self.view addSubview:_tableView];
        _tableView.estimatedRowHeight = 15*kWindowH;
        [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
        
        [_tableView registerClass:[ArticleCell class] forCellReuseIdentifier:@"Cell"];
        
    }
    return _tableView;
}
- (ArticleViewModel *)articleVM
{
    if (!_articleVM) {
        _articleVM = [[ArticleViewModel alloc] initWithstrRow:_strRow.integerValue];
    }
    return _articleVM;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.readBtn.hidden = NO;
    [self.tableView.header beginRefreshing];
    
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
    [self showProgress];
    [self.articleVM getDataFromNetCompleteHandle:^(NSError *error) {
        if (error) {
            [self showErrorMsg:error.localizedDescription];
        }else{
            [self.tableView reloadData];
        }
        [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
        [self hideProgress];
        
    }];

    
    
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [MobClick beginLogPageView:@"ArticleViewController"];
}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [self.syn stopSpeakingAtBoundary:AVSpeechBoundaryImmediate];
    [MobClick endLogPageView:@"ArticleViewController"];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
#pragma mark - UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.articleVM.rowNumber;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    ArticleCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
    
    cell.strContTitleLb.text = [self.articleVM strContTitleForRow:indexPath.row];
    cell.strContAuthorLb.text = [self.articleVM strContAuthorForRow:indexPath.row];
    cell.strContentLb.text = [cell stringInstrContentLb:[self.articleVM stringContentForRow:indexPath.row]];
    //DDLogVerbose(@"%@",cell.strContentLb.text);
    cell.sAuthLb.text = [self.articleVM sAuthForRow:indexPath.row];
    _readContent = cell.strContentLb.text;
    
    cell.strContAuthorIntroduceLb.text = [self.articleVM strContAuthorIntroduceForRow:indexPath.row];
    return cell;
    
}
- (CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return UITableViewAutomaticDimension;
}

#pragma mark
- (void)speechSynthesizer:(AVSpeechSynthesizer *)synthesizer didStartSpeechUtterance:(AVSpeechUtterance *)utterance{
    _readBtn.selected = !_readBtn.selected;
}
- (void)speechSynthesizer:(AVSpeechSynthesizer *)synthesizer didFinishSpeechUtterance:(AVSpeechUtterance *)utterance{
    _readBtn.selected = !_readBtn.selected;
}
- (void)speechSynthesizer:(AVSpeechSynthesizer *)synthesizer didPauseSpeechUtterance:(AVSpeechUtterance *)utterance{
    
}
- (void)speechSynthesizer:(AVSpeechSynthesizer *)synthesizer didContinueSpeechUtterance:(AVSpeechUtterance *)utterance{
    
}
- (void)speechSynthesizer:(AVSpeechSynthesizer *)synthesizer didCancelSpeechUtterance:(AVSpeechUtterance *)utterance{
    _readBtn.selected = !_readBtn.selected;
}

@end
