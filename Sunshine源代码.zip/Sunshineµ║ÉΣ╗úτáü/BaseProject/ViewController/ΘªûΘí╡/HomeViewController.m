//
//  HomeViewController.m
//  BaseProject
//
//  Created by ios－10 on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "HomeViewController.h"
#import "HomePageViewController.h"
#import "Factory.h"

@interface HomeViewController ()

@end

@implementation HomeViewController
+ (UINavigationController *)standardHomeNavi
{
    static UINavigationController *navi = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        HomeViewController *vc = [[HomeViewController alloc] initWithViewControllerClasses:[self viewControllerClasses] andTheirTitles:[self itemNames]];
        //例如设置第一个控制器的某个属性的值, KVC
        //vc setValue:[values[0]] forKey:keys[0]
        vc.menuViewStyle = WMMenuViewStyleDefault;
        vc.menuHeight = PAGETABBARH;
        vc.menuItemWidth = kWindowW;
        vc.menuBGColor = kRGBColor(225, 225, 225);

        vc.keys = [self vcKeys];
        vc.values = [self vcValues];
        navi = [[UINavigationController alloc] initWithRootViewController:vc];
    });
    return navi;
}

/* 返回某一年某一月的天数 **/
+ (NSInteger)daysWithYear:(NSInteger)year andMonth:(NSInteger)month
{
    switch (month) {
        case 1:
        case 3:
        case 5:
        case 7:
        case 8:
        case 10:
        case 12:
            return 31;
            break;
        case 4:
        case 6:
        case 9:
        case 11:
            return 30;
            break;
        case 2:
            return (year % 400 == 0 ||( year % 4 == 0 && year % 100 != 0)) ? 29 : 28;
        default:
            break;
    }
    return -1;
}

//
+ (NSArray *)vcValues{
    NSInteger count = 0;
    NSMutableArray *array = [NSMutableArray new];
    /** 获取当前时间 */
    NSDate * senddate=[NSDate date];
    NSCalendar * cal=[NSCalendar currentCalendar];
    NSUInteger unitFlags=NSDayCalendarUnit|NSMonthCalendarUnit|NSYearCalendarUnit;
    NSDateComponents * conponent= [cal components:unitFlags fromDate:senddate];
    
    NSInteger year=[conponent year];
    NSInteger month=[conponent month];
    NSInteger day=[conponent day];
    
    NSString *strMarketTime = [NSString stringWithFormat:@"%4ld-%02ld-%02ld",year,month,day];
    [array addObject:strMarketTime];
    do {
        if (day > 1 || month > 1) {
            day -= 1;
            strMarketTime = [NSString stringWithFormat:@"%4ld-%02ld-%02ld",year,month,day];
            [array addObject:strMarketTime];
            count ++;
            continue;
        }else if (month > 1){
            month -= 1;
            NSInteger days = [self daysWithYear:year andMonth:month];
            day = days;
            strMarketTime = [NSString stringWithFormat:@"%4ld-%02ld-%02ld",year,month,day];
            [array addObject:strMarketTime];
            count ++;
            continue;
        }else{
            month = 12;
            day = 31;
            strMarketTime = [NSString stringWithFormat:@"%4ld-%02ld-%02ld",year,month,day];
            [array addObject:strMarketTime];
            count ++;
            continue;
        }

    } while (count < 9);
    DDLogVerbose(@"%@", array);
    return [array copy];
}
/** 提供每个VC对应的key值数组 */
+ (NSArray *)vcKeys{
    NSMutableArray *arr = [NSMutableArray new];
    for (id obj in [self vcValues]) {
        [arr addObject:@"strMarketTime"];
    }
    return [arr copy];
}

/** 提供题目数组 */
+ (NSArray *)itemNames{
    return @[@"PAGE 1", @"PAGE 2", @"PAGE 3", @"PAGE 4", @"PAGE 5", @"PAGE 6", @"PAGE 7", @"PAGE 8", @"PAGE 9", @"PAGE 10"];
}
/** 提供每个题目对应的控制器的类型。题目和类型数量必须一致 */
+ (NSArray *)viewControllerClasses{
    NSMutableArray *arr = [NSMutableArray new];
    for (id obj in [self itemNames]) {
        [arr addObject:[HomePageViewController class]];
    }
    return [arr copy];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    
    [Factory addMenuItemToVC:self];
    
    self.title = @"Sunshine";
    
    self.titleColorNormal = [UIColor grayColor];
    self.titleColorSelected = kMainColor;
    self.titleSizeNormal = 10;
    self.titleSizeSelected = 20;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
