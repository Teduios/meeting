//
//  HomePageViewController.m
//  BaseProject
//
//  Created by ios－z on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "HomePageViewController.h"
#import "HomePageViewModel.h"
#import "HomePageViewController.h"
#import "HomePageCell.h"

@interface HomePageViewController ()<UITableViewDataSource,UITableViewDelegate>
@property (nonatomic,strong)UITableView  *tableView;
@property (nonatomic,strong)HomePageViewModel *homePageVM;
@end

@implementation HomePageViewController

-(UITableView *)tableView{
    if (!_tableView) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStylePlain];
        
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.allowsSelection = NO;
        _tableView.separatorStyle  = UITableViewCellSeparatorStyleNone;
        _tableView.showsVerticalScrollIndicator = NO;
        _tableView.estimatedRowHeight = kWindowH;
        [self.view addSubview:_tableView];
        [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
        
        [_tableView registerClass:[HomePageCell class] forCellReuseIdentifier:@"Cell"];
    }
    return _tableView;
}
-(HomePageViewModel *)homePageVM{
    if (!_homePageVM) {
        _homePageVM = [[HomePageViewModel alloc]initWithStrMarketTime:_strMarketTime];
    }
    return _homePageVM;
}
#pragma mark - UITableView
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.homePageVM.rowNumber;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    HomePageCell *cell  = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
    cell.strHpTitleLb.text = [self.homePageVM strHpTitleForRow:indexPath.row];
    
    [cell.strOriginalImg.imageView setImageWithURL:[self.homePageVM strOriginalImgURLForRow:indexPath.row]];
  
    cell.strAuthorLb.text = [self.homePageVM strAuthorLbForRow:indexPath.row];

    cell.strContentLb.text = [self.homePageVM strContentLbForRow:indexPath.row];
    cell.strMarketTimeLb.text = [self.homePageVM strMarketTimeLbForRow:indexPath.row];
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return UITableViewAutomaticDimension;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [self.tableView.header beginRefreshing];
    
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
    [self showProgress];
    [self.homePageVM getDataFromNetCompleteHandle:^(NSError *error) {
        if (error) {
            [self showErrorMsg:error.localizedDescription];
        }else{
            [self.tableView reloadData];
        }
        [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];       
        [self hideProgress];
    }];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
