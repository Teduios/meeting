//
//  ThingViewController.m
//  BaseProject
//
//  Created by ios－z on 15/11/14.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ThingViewController.h"
#import "ThingViewModel.h"
#import "ThingCell.h"

@interface ThingViewController () <UITableViewDataSource, UITableViewDelegate>
@property (nonatomic, strong) ThingViewModel *thingVM;
@property (nonatomic, strong) UITableView *tableView;
@end

@implementation ThingViewController

- (ThingViewModel *)thingVM
{
    if (!_thingVM) {
        _thingVM = [[ThingViewModel alloc] initWithStrRow:_strRow];
    }
    return _thingVM;
}
- (UITableView *)tableView
{
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.allowsSelection = NO;
        _tableView.showsVerticalScrollIndicator = NO;
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        
        [self.view addSubview:_tableView];
        
        [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
        
        [_tableView registerClass:[ThingCell class] forCellReuseIdentifier:@"Cell"];
    }
    return _tableView;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    [self.tableView.header beginRefreshing];
    
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
    [self showProgress];
    [self.thingVM getDataFromNetCompleteHandle:^(NSError *error) {
        if (error) {
            [self showErrorMsg:error.localizedDescription];
        }else{
            [self.tableView reloadData];
        }
        [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
        [self hideProgress];
        
    }];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - 
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.thingVM.rowNumber;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    ThingCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell" forIndexPath:indexPath];
    
    [cell.strBuIV.imageView setImageWithURL:[self.thingVM strBuURLForRow:indexPath.row]];
    cell.strTtLb.text = [self.thingVM strTtForRow:indexPath.row];
    cell.strTcLb.text = [self.thingVM strTcForRow:indexPath.row];
    
    return cell;
}
- (CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(nonnull NSIndexPath *)indexPath{
    return UITableViewAutomaticDimension;
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
