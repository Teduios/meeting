//
//  QuestionViewController.m
//  BaseProject
//
//  Created by ios－z on 15/11/14.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "QuestionViewController.h"
#import "QuestionViewModel.h"
#import "QuestionNetManager.h"
#import "QuestionCell.h"

@interface QuestionViewController () <UITableViewDataSource, UITableViewDelegate>
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) QuestionViewModel *questionVM;
@end

@implementation QuestionViewController

- (QuestionViewModel *)questionVM
{
    if (!_questionVM) {
        _questionVM = [[QuestionViewModel alloc] initWithStrRow:_strRow];
    }
    return _questionVM;
}
- (UITableView *)tableView
{
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.showsVerticalScrollIndicator = NO;
        _tableView.allowsSelection = NO;
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        [self.view addSubview:_tableView];
        [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
        
        [_tableView registerClass:[QuestionCell class] forCellReuseIdentifier:@"Cell"];
    }
    return _tableView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.tableView.header beginRefreshing];
    
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
    [self showProgress];
    [self.questionVM getDataFromNetCompleteHandle:^(NSError *error) {
        if (error) {
            [self showErrorMsg:error.localizedDescription];
        }else{
           [self.tableView reloadData];
        }
        [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
        [self hideProgress];
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - UITableViewDelegate

#pragma mark - UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    DDLogVerbose(@"row = %ld", self.questionVM.rowNumber);
    return self.questionVM.rowNumber;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{ 
    QuestionCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
    
    //cell.questionIV.image = [UIImage imageNamed:@"question"];
    cell.strQuestionTitleLb.text = [self.questionVM strQuestionTitleForRow:indexPath.row];
    cell.strQuestionContentLb.text = [cell stringInstrContentLb:[self.questionVM stringQusetionContentForRow:indexPath.row]];
    cell.strAnswerTitleLb.text = [self.questionVM strAnswerTitleForRow:indexPath.row];
    cell.strAnswerContentLb.text = [cell stringInstrContentLb:[self.questionVM stringAnswerContentForRow:indexPath.row]];
    cell.sEditorLb.text = [self.questionVM sEditorForRow:indexPath.row];
    [cell.questionIV.imageView setImage:[UIImage imageNamed:@"question"]];
    [cell.answerIV.imageView setImage:[UIImage imageNamed:@"answer"]];
    
    return cell;
}
- (CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return UITableViewAutomaticDimension;
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
