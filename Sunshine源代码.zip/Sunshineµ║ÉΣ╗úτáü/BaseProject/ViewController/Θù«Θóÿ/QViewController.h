//
//  HomeViewController.h
//  BaseProject
//
//  Created by ios－10 on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "WMPageController.h"

@interface QViewController : WMPageController
//内容页的首页应该是单例的，每次进程都只初始化一次
+ (UINavigationController *)standardQuestionNavi;
@end
