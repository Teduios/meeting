//
//  ThingModel.h
//  BaseProject
//
//  Created by ios－10 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"

@class ThingEnttgModel;
@interface ThingModel : BaseModel

@property (nonatomic, strong) ThingEnttgModel *entTg;

@property (nonatomic, copy) NSString *rs;

@end
@interface ThingEnttgModel : NSObject

@property (nonatomic, copy) NSString *strTt;

@property (nonatomic, copy) NSString *strId;

@property (nonatomic, copy) NSString *strPn;

@property (nonatomic, copy) NSString *strTm;

@property (nonatomic, copy) NSString *strLastUpdateDate;

@property (nonatomic, copy) NSString *strBu;

@property (nonatomic, copy) NSString *strWu;

@property (nonatomic, copy) NSString *strTc;

@end

