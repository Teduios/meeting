//
//  QuestionModel.m
//  BaseProject
//
//  Created by ios－10 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "QuestionModel.h"

@implementation QuestionModel

@end
@implementation QuestionQuestionadentityModel

@end


@implementation QuestionQuestionAdEntityEntqncmtModel

@end


