//
//  QuestionModel.h
//  BaseProject
//
//  Created by ios－10 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"

@class QuestionQuestionadentityModel,QuestionQuestionAdEntityEntqncmtModel;
@interface QuestionModel : BaseModel

@property (nonatomic, strong) QuestionQuestionadentityModel *questionAdEntity;

@property (nonatomic, copy) NSString *result;

@end
@interface QuestionQuestionadentityModel : NSObject

@property (nonatomic, copy) NSString *strQuestionContent;

@property (nonatomic, copy) NSString *strQuestionMarketTime;

@property (nonatomic, copy) NSString *strQuestionId;

@property (nonatomic, copy) NSString *sEditor;

@property (nonatomic, copy) NSString *strPraiseNumber;

@property (nonatomic, copy) NSString *strLastUpdateDate;

@property (nonatomic, strong) QuestionQuestionAdEntityEntqncmtModel *entQNCmt;

@property (nonatomic, copy) NSString *strDayDiffer;

@property (nonatomic, copy) NSString *sWebLk;

@property (nonatomic, copy) NSString *strAnswerTitle;

@property (nonatomic, copy) NSString *strAnswerContent;

@property (nonatomic, copy) NSString *strQuestionTitle;

@end

@interface QuestionQuestionAdEntityEntqncmtModel : NSObject

@property (nonatomic, copy) NSString *upFg;

@property (nonatomic, copy) NSString *strCnt;

@property (nonatomic, copy) NSString *strId;

@property (nonatomic, copy) NSString *strD;

@property (nonatomic, copy) NSString *pNum;

@end

