//
//  ArticleModel.h
//  BaseProject
//
//  Created by ios－10 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"


@class ArticleContententityModel;
@interface ArticleModel : BaseModel


@property (nonatomic, strong) ArticleContententityModel *contentEntity;

@property (nonatomic, copy) NSString *result;

@end

@interface ArticleContententityModel : NSObject

@property (nonatomic, copy) NSString *strContent;

@property (nonatomic, copy) NSString *sRdNum;

@property (nonatomic, copy) NSString *strContentId;

@property (nonatomic, copy) NSString *subTitle;

@property (nonatomic, copy) NSString *strContDayDiffer;

@property (nonatomic, copy) NSString *strPraiseNumber;

@property (nonatomic, copy) NSString *strLastUpdateDate;

@property (nonatomic, copy) NSString *sGW;

@property (nonatomic, copy) NSString *sAuth;

@property (nonatomic, copy) NSString *sWebLk;

@property (nonatomic, copy) NSString *wImgUrl;

@property (nonatomic, copy) NSString *strContAuthorIntroduce;

@property (nonatomic, copy) NSString *strContTitle;

@property (nonatomic, copy) NSString *sWbN;

@property (nonatomic, copy) NSString *strContAuthor;

@property (nonatomic, copy) NSString *strContMarketTime;

@end

