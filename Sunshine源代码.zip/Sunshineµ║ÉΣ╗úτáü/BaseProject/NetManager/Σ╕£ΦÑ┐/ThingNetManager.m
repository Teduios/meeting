//
//  ThingNetManager.m
//  BaseProject
//
//  Created by ios－10 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ThingNetManager.h"
#import "ThingModel.h"
#define kThingPath @"http://rest.wufazhuce.com/OneForWeb/one/o_f"

@implementation ThingNetManager

/** 获取问题页 */
+ (id)getThingWithStrTm:(NSString *)strTm strRow:(NSInteger)strRow completionHandle:(void (^)(id, NSError *))completionHandle
{
    return [self GET:kThingPath parameters:@{@"strDate":strTm, @"strRow":@(strRow)} completionHandler:^(id responseObj, NSError *error) {
        completionHandle([ThingModel objectWithKeyValues:responseObj], error);
    }];
}

@end
