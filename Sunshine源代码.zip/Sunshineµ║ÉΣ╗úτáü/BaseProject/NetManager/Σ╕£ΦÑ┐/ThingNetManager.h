//
//  ThingNetManager.h
//  BaseProject
//
//  Created by ios－10 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseNetManager.h"

@interface ThingNetManager : BaseNetManager

/** 获取问题页 */
+ (id)getThingWithStrTm:(NSString *)strTm strRow:(NSInteger)sreRow kCompletionHandle;

@end
