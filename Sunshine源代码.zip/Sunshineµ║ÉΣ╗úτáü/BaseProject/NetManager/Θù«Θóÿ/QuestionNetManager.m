//
//  QuestionNetManager.m
//  BaseProject
//
//  Created by ios－10 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "QuestionNetManager.h"
#import "QuestionModel.h"

#define kQuestionPath @"http://rest.wufazhuce.com/OneForWeb/one/getQ_N"
@implementation QuestionNetManager
+ (id)getQuestionWithStrQuestionMarketTime:(NSString *)strQuestionMarketTime strRow:(NSInteger)strRow completionHandle:(void (^)(id, NSError *))completionHandle
{
    return [self GET:kQuestionPath parameters:@{@"strDate":strQuestionMarketTime,@"strUi":@"",@"strRow":@(strRow)} completionHandler:^(id responseObj, NSError *error) {
        completionHandle([QuestionModel objectWithKeyValues:responseObj], error);
    }];
}
@end
