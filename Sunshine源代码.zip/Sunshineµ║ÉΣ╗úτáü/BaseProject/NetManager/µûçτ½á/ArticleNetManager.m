//
//  ArticleNetManager.m
//  BaseProject
//
//  Created by ios－10 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ArticleNetManager.h"
#import "ArticleModel.h"
#define kArticlePath @"http://rest.wufazhuce.com/OneForWeb/one/getC_N"

@implementation ArticleNetManager

+ (id)getArticleWithStrContMarketTime:(NSString *)strContMarketTime strRow:(NSInteger)strRow completionHandle:(void (^)(id, NSError *))completionHandle
{
    NSDictionary *params = @{@"strDate":strContMarketTime , @"strRow":@(strRow),@"strMS":@(1)};
    return [self GET:kArticlePath parameters:params completionHandler:^(id responseObj, NSError *error) {
        completionHandle([ArticleModel objectWithKeyValues:responseObj], error);
    }];
}


@end
