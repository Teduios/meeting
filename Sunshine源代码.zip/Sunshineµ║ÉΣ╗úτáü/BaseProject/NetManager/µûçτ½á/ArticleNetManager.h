//
//  ArticleNetManager.h
//  BaseProject
//
//  Created by ios－10 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseNetManager.h"



@interface ArticleNetManager : BaseNetManager
/** 获取文章 */
+ (id)getArticleWithStrContMarketTime:(NSString *)strContMarketTime strRow:(NSInteger)strRow kCompletionHandle;

@end
