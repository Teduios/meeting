//
//  HomePageNetManager.h
//  BaseProject
//
//  Created by ios－10 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseNetManager.h"

@interface HomePageNetManager : BaseNetManager
/** 获取首页文章 */
+ (id)getPageWithStrMarketTime:(NSString *)strMarketTime kCompletionHandle;

@end
