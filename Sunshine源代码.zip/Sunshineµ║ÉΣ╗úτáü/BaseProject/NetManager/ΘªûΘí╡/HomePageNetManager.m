//
//  HomePageNetManager.m
//  BaseProject
//
//  Created by ios－10 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "HomePageNetManager.h"
#import "HomePageModel.h"

#define kHomePathPath @"http://bea.wufazhuce.com/OneForWeb/one/getHpinfo"


@implementation HomePageNetManager

/** 获取首页文章 */
+ (id)getPageWithStrMarketTime:(NSString *)strMarketTime completionHandle:(void (^)(id, NSError *))completionHandle
{
    NSDictionary  *parmas = @{@"strDate":strMarketTime,@"strLastUpdateDate":@""};
    return [self GET:kHomePathPath parameters:parmas completionHandler:^(id responseObj, NSError *error) {
        completionHandle([HomePageModel objectWithKeyValues:responseObj], error);
    }];
}


@end
