//
//  ArticleVIewModel.m
//  BaseProject
//
//  Created by ios－z on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ArticleViewModel.h"
#import "ArticleNetManager.h"
#import "ArticleModel.h"

@implementation ArticleViewModel

- (NSString *)today
{
    /** 获取当前时间 */
    NSDate * senddate=[NSDate date];
    NSCalendar * cal=[NSCalendar currentCalendar];
    NSUInteger unitFlags=NSDayCalendarUnit|NSMonthCalendarUnit|NSYearCalendarUnit;
    NSDateComponents * conponent= [cal components:unitFlags fromDate:senddate];
    
    NSInteger year=[conponent year];
    NSInteger month=[conponent month];
    NSInteger day=[conponent day];
    
    return [NSString stringWithFormat:@"%4ld-%02ld-%02ld",year,month,day];
    
}
- (instancetype)initWithstrRow:(NSInteger)strRow{
    if (self = [super init]) {
        _strRow = strRow;
    }
    return self;
}

- (ArticleContententityModel *)modelForRow:(NSInteger)row
{
    return self.dataArr[row];
}
- (void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle{
    self.dataTask = [ArticleNetManager getArticleWithStrContMarketTime:[self today] strRow:_strRow completionHandle:^(ArticleModel *model, NSError *error) {
        if (!error) {
            [self.dataArr addObject:model.contentEntity];
        }
        completionHandle(error);
    }];
}
- (NSInteger)rowNumber
{
    return self.dataArr.count;
}
- (NSString *)strContTitleForRow:(NSInteger)row
{
    return [self modelForRow:row].strContTitle;
}
- (NSString *)strContAuthorForRow:(NSInteger)row
{
    return [self modelForRow:row].strContAuthor;
}
- (NSString *)strContentForRow:(NSInteger)row
{
    return [self modelForRow:row].strContent;
}
- (NSString *)strContAuthorIntroduceForRow:(NSInteger)row
{
    return [self modelForRow:row].strContAuthorIntroduce;
}
- (NSString *)sAuthForRow:(NSInteger)row
{
    return [self modelForRow:row].sAuth;
}
- (NSArray *)stringContentForRow:(NSInteger)row
{
    return [[self strContentForRow:row] componentsSeparatedByString:@"<br>"];
}
@end

