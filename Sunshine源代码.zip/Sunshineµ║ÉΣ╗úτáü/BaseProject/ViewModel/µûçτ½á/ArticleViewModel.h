//
//  ArticleVIewModel.h
//  BaseProject
//
//  Created by ios－z on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"

@interface ArticleViewModel : BaseViewModel

@property (nonatomic, strong) NSDictionary *dataDic;
- (instancetype)initWithstrRow:(NSInteger)strRow;
@property (nonatomic) NSInteger strRow;

@property (nonatomic)NSInteger rowNumber;
- (NSString *)strContTitleForRow:(NSInteger)row;
- (NSString *)strContAuthorForRow:(NSInteger)row;
- (NSString *)strContentForRow:(NSInteger)row;
- (NSString *)strContAuthorIntroduceForRow:(NSInteger)row;
- (NSString *)sAuthForRow:(NSInteger)row;

- (NSArray *)stringContentForRow:(NSInteger)row;
@end
