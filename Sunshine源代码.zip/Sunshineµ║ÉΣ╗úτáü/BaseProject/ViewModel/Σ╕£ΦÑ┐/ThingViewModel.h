//
//  ThingViewModel.h
//  BaseProject
//
//  Created by ios－z on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"

@interface ThingViewModel : BaseViewModel

@property (nonatomic) NSInteger rowNumber;

- (instancetype)initWithStrRow:(NSInteger)strRow;
@property (nonatomic) NSInteger strRow;

- (NSURL *)strBuURLForRow:(NSInteger)row;
- (NSString *)strTtForRow:(NSInteger)row;
- (NSString *)strTcForRow:(NSInteger)row;

@end
