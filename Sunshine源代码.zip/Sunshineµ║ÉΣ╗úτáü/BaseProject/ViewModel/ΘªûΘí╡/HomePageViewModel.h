//
//  HomePageViewModel.h
//  BaseProject
//
//  Created by ios－z on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "ArticleNetManager.h"

@interface HomePageViewModel : BaseViewModel
/** 根据View层写 */
@property (nonatomic) NSInteger rowNumber;

- (NSString *)strHpTitleForRow:(NSInteger)row;
- (NSURL *)strOriginalImgURLForRow:(NSInteger)row;
- (NSString *)strAuthorLbForRow:(NSInteger)row;
- (NSString *)strContentLbForRow:(NSInteger)row;
- (NSString *)strMarketTimeLbForRow:(NSInteger)row;

- (instancetype)initWithStrMarketTime:(NSString *)strMarketTime;
@property (nonatomic, strong) NSString *strMarketTime;



@end
