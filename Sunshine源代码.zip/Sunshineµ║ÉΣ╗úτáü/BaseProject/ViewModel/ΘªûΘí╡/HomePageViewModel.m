//
//  HomePageViewModel.m
//  BaseProject
//
//  Created by ios－z on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "HomePageViewModel.h"
#import "HomePageNetManager.h"
#import "HomePageModel.h"
#import "HomePageViewController.h"

@implementation HomePageViewModel
- (NSInteger)rowNumber
{
    return self.dataArr.count;
}
- (instancetype)initWithStrMarketTime:(NSString *)strMarketTime
{
    if (self = [super init]) {
        _strMarketTime = strMarketTime;
    }
    return self;
}

- (HomePageHpentityModel *)modelForRow:(NSInteger)row{
    return self.dataArr[row];
}
- (void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle{
    self.dataTask = [HomePageNetManager getPageWithStrMarketTime:_strMarketTime completionHandle:^(HomePageModel *model, NSError *error) {
        if (!error) {
            [self.dataArr addObject:model.hpEntity];
        }            
        completionHandle(error);
    }];
}

-(NSString *)strHpTitleForRow:(NSInteger)row{
    return [self modelForRow:row].strHpTitle;
}
- (NSURL *)strOriginalImgURLForRow:(NSInteger)row{
    return [NSURL URLWithString:[self modelForRow:row].strOriginalImgUrl];
}
- (NSString *)strAuthorLbForRow:(NSInteger)row{
    return [self modelForRow:row].strAuthor;
}
- (NSString *)strContentLbForRow:(NSInteger)row{
    return [self modelForRow:row].strContent;
}
- (NSString *)strMarketTimeLbForRow:(NSInteger)row{
    return [self modelForRow:row].strMarketTime;
}
@end
