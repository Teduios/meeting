//
//  QuestionViewModel.m
//  BaseProject
//
//  Created by ios－z on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "QuestionViewModel.h"
#import "QuestionModel.h"
#import "QuestionNetManager.h"

@implementation QuestionViewModel

- (instancetype)initWithStrRow:(NSInteger)strRow
{
    if (self = [super init]) {
        _strRow = strRow;
    }
    return self;
}
- (NSInteger)rowNumber
{
    return self.dataArr.count;
}
- (QuestionQuestionadentityModel *)modelForRow:(NSInteger)row
{
    return self.dataArr[row];
}
- (NSString *)today
{
    /** 获取当前时间 */
    NSDate * senddate=[NSDate date];
    NSCalendar * cal=[NSCalendar currentCalendar];
    NSUInteger unitFlags=NSDayCalendarUnit|NSMonthCalendarUnit|NSYearCalendarUnit;
    NSDateComponents * conponent= [cal components:unitFlags fromDate:senddate];
    
    NSInteger year=[conponent year];
    NSInteger month=[conponent month];
    NSInteger day=[conponent day];
    
    return [NSString stringWithFormat:@"%4ld-%02ld-%02ld",year,month,day];

}
- (void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle
{
    self.dataTask = [QuestionNetManager getQuestionWithStrQuestionMarketTime:[self today] strRow:_strRow completionHandle:^(QuestionModel *model, NSError *error) {
        if (!error) {
            [self.dataArr addObject:model.questionAdEntity];
        }        
        completionHandle(error);
    }];
}
- (NSString *)strQuestionTitleForRow:(NSInteger)row
{
    return [self modelForRow:row].strQuestionTitle;
}
- (NSString *)strQuestionContentForRow:(NSInteger)row
{
    return [self modelForRow:row].strQuestionContent;
}
- (NSString *)strAnswerTitleForRow:(NSInteger)row
{
    return [self modelForRow:row].strAnswerTitle;
}
- (NSString *)strAnswerContentForRow:(NSInteger)row
{
    return [self modelForRow:row].strAnswerContent;
}
- (NSString *)sEditorForRow:(NSInteger)row
{
    return [self modelForRow:row].sEditor;
}
- (NSArray *)stringAnswerContentForRow:(NSInteger)row
{
    return [[self strAnswerContentForRow:row] componentsSeparatedByString:@"<br>"];
}
- (NSArray *)stringQusetionContentForRow:(NSInteger)row
{
    return [[self strQuestionContentForRow:row] componentsSeparatedByString:@"<br>"];
}
@end
