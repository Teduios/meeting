//
//  QuestionViewModel.h
//  BaseProject
//
//  Created by ios－z on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"

@interface QuestionViewModel : BaseViewModel

- (instancetype)initWithStrRow:(NSInteger)strRow;
@property (nonatomic) NSInteger strRow;

@property (nonatomic) NSInteger rowNumber;
- (NSString *)strQuestionTitleForRow:(NSInteger)row;
- (NSString *)strQuestionContentForRow:(NSInteger)row;
- (NSString *)strAnswerTitleForRow:(NSInteger)row;
- (NSString *)strAnswerContentForRow:(NSInteger)row;
- (NSString *)sEditorForRow:(NSInteger)row;

- (NSArray *)stringAnswerContentForRow:(NSInteger)row;
- (NSArray *)stringQusetionContentForRow:(NSInteger)row;
@end
